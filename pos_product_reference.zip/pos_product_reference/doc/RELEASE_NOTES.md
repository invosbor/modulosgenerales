## Module <pos_product_reference>

#### 6.04.2019
#### Version 12.0.1.0.0
##### ADD
- Initial commit for Product reference in Pos
