Product Price Update v12
========================

Product price update is an effective module which helps to update the price of any product.
We can update sale price and cost price of any product on a single click.

Installation
============

Just select it from available modules to install it, there is no need to extra installations.

Configuration
=============

Nothing to configure.


Credits
=======
* Cybrosys Techno Solutions, https://www.cybrosys.com

Author
------
*  v10 : Saritha Sahadevan
*  v11 : Niyas Raphy
*  v12 : Vinaya S B
