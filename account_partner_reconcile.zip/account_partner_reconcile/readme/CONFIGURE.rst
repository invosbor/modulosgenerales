The button is visible only to users that belong to the accounting groups
"Accountant" or "Adviser".