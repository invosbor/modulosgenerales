## Module <pos_multi_note>

#### 26.08.2019
#### Version 12.0.1.0.0
##### ADD
- Initial commit
