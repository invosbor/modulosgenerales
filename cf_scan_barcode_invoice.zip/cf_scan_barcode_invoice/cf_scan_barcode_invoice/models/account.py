from odoo import api, fields, models, _
from odoo.exceptions import Warning
from datetime import datetime
from odoo.tools import float_compare

class AccountInvoice(models.Model):
    _inherit = 'account.invoice'

    barcode_scan = fields.Char(string='Barcode')

    @api.onchange('barcode_scan')
    def barcode_scanning(self):
        if self.barcode_scan:
            if not self.invoice_line_ids:
                self.barcode_scan = None
                raise Warning('There is no Product defined in the Invoice.')
            if self.barcode_scan:
                self.barcode_scan = self.barcode_scan.strip()
            match = False
            product_obj = self.env['product.product']
            product_id = product_obj.search([('barcode', '=', self.barcode_scan)])
            #### Check for Internal Reference when barcode not found ####
            if not product_id:
                product_id = product_obj.search([('default_code', '=', self.barcode_scan)])
            #### Give Warning when Barcode/Internal Reference for product is Duplicate ####
            if len(product_id) > 1:
                self.barcode_scan = None
                raise Warning('Barcode/Internal Reference cannot be Duplicate.')
            #### Give Warning when Barcode/Internal Reference for product is not exist in the Database ####
            if self.barcode_scan and not product_id:
                self.barcode_scan = None
                raise Warning('No product is available for this Barcode/Internal Reference.')
            #### Check if Product already exist in line then we will increment the Qty####
            if self.barcode_scan and self.invoice_line_ids:
                for line in self.invoice_line_ids:
                    if line.product_id.barcode == self.barcode_scan or line.product_id.default_code == self.barcode_scan:
                        line.quantity += 1
                        match = True
            self.barcode_scan = None
            #### if Product not already exist then create a new line ####
            if product_id and not match:
                raise Warning('This Barcode/Internal Reference Product is not available in the Invoice line.')
