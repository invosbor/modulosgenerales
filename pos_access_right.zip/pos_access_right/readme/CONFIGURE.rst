Once installed, you have to give correct access right to your cashiers.
