This module extends the functionality of Invoicing to allow you to apply fixed
amount discounts at invoice line level.

The module also extends the invoice report to show fixed discount.
