# -*- coding: utf-8 -*-

from . import website_support_ticket
from . import res_partner
from . import website_support_help
from . import website_support_settings
from . import mail_template
from . import website_support_department
from . import website_support_sla