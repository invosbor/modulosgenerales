.. _changelog:

Changelog
=========

`Version 1.0 (2019)`
-------------------------
- First release for Odoo 12.0.
