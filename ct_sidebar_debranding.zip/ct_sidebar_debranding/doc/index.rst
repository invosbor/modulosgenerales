Installation
------------

- Backup your Odoo

- After purchase you will receive a receipt with a link to download the module

- Extract the module and upload (place it) into your "custom modules" folder

- Restart the Odoo server

- Log in to Odoo and activate the developer mode

- Go to "Apps" tab and click "Update Apps list"

- Find the module and hit the "Install" button

- Restart Odoo

- Feel free to contact to get a tutorials on how to install modules on different systems

Compatibility
------------

- Fully Supports Odoo Version 12.0 Community

- Module tested on clean Odoo installation, no errors detected
