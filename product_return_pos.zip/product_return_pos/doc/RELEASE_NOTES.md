## Module <product_return_pos>

#### 24.04.2019
#### Version 12.0.1.0.0
##### ADD
- Initial commit for Product Return In POS

#### 30.08.2019
#### Version 12.0.1.1.0
##### FIX
- Fixed Qweb file load issue.
