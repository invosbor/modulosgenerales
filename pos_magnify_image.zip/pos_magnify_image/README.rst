=============================
Pos Product Magnify Image V11
=============================

This module allow to magnify product image in pos.

Installation
============

Just select it from available modules to install it, there is no need to extra installations.

Configuration
=============

Nothing to configure.

Usage
=====

* + icon on pos product image.
* On clicking on + icon, display pop up with magnified product image.


Credits
=======
Developer: Aswani pc @ cybrosys

