This module adds a menu entry **Account Type** under *Invoicing > Configuration > Accounting*
because this menu entry doesn't exists in the official *account* module of Odoo 12.
